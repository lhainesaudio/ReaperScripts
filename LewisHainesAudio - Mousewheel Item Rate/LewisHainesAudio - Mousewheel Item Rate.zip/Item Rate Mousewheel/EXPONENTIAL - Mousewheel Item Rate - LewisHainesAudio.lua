--ITEM RATE MOUSEWHEEL BY LEWIS HAINES AUDIO

scalingAmount = 0.08 --change this number to modify how intense the rate change is

  local is_new_value,filename,sectionID,cmdID,mode,resolution,val = reaper.get_action_context()   -- gets mousewheel input and accounts for direction
    if val == 0 or not is_new_value then return end
      if val > 0 then 
        val = 1
        incr = 1+scalingAmount  
      else                                                                    
        val = -1 
        incr = -1+scalingAmount
      end

   local window, segment, details = reaper.BR_GetMouseCursorContext()         --selects item under mouse cursor
      validItem = reaper.BR_GetMouseCursorContext_Item()
     if validItem ~= nil then
      reaper.SetMediaItemSelected(validItem, 1)
      reaper.UpdateArrange()
     else return end

   hItem = reaper.GetSelectedMediaItem(0,0)                                   --checks if media item is selected, terminates if not
   if hItem then
    selTake = reaper.GetMediaItemTake(hItem, 0)
   else return end
   
   
   it_Length = reaper.GetMediaItemInfo_Value(hItem, "D_LENGTH")
   it_Rate = reaper.GetMediaItemTakeInfo_Value(selTake, "D_PLAYRATE")
   it_pPitch = reaper.GetMediaItemTakeInfo_Value(selTake, "B_PPITCH")
    
    if it_pPitch == 1 then
      reaper.SetMediaItemTakeInfo_Value(selTake, "B_PPITCH", 0)               --if preserve pitch is on, turns it off
    end
    
if val ~= 0 then
  reaper.SetMediaItemTakeInfo_Value(selTake, "D_PLAYRATE", it_Rate * incr)    --change item playrate
  reaper.SetMediaItemInfo_Value(hItem, "D_LENGTH", it_Length / incr)          --change item length to match
end
  
---DEBUG---
--reaper.ShowConsoleMsg("Incr = "..incr.."\n" )
--reaper.ShowConsoleMsg("Rate = "..it_Rate.."\n")
--reaper.ShowConsoleMsg("pPitch = "..it_pPitch.."\n")

reaper.UpdateArrange()

reaper.defer(function() end)
